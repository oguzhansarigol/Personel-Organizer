﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace OOP_II_Project
{
    public abstract class Reminder
    {
        public DateTime Date { get; set; }
        public string Summary { get; set; }
        public string Description { get; set; }

        public Reminder(DateTime date, string summary, string description)
        {
            Date = date;
            Summary = summary;
            Description = description;
        }

        public abstract void Notify(Form form);
    }

    public class MeetingReminder : Reminder
    {
        public MeetingReminder(DateTime date, string summary, string description)
            : base(date, summary, description) { }

        public override void Notify(Form form)
        {
            form.Text = Summary;
            ShakeWindow(form);
        }

        private void ShakeWindow(Form form)
        {
            var original = form.Location;
            var rnd = new Random(1337);
            const int shakeAmplitude = 10;
            for (int i = 0; i < 10; i++)
            {
                var x = original.X + rnd.Next(-shakeAmplitude, shakeAmplitude);
                var y = original.Y + rnd.Next(-shakeAmplitude, shakeAmplitude);
                form.Location = new Point(x, y);
                System.Threading.Thread.Sleep(20);
            }
            form.Location = original;
        }
    }

    public class TaskReminder : Reminder
    {
        public TaskReminder(DateTime date, string summary, string description)
            : base(date, summary, description) { }

        public override void Notify(Form form)
        {
            form.Text = Summary;
            ShakeWindow(form);
        }

        private void ShakeWindow(Form form)
        {
            var original = form.Location;
            var rnd = new Random(1337);
            const int shakeAmplitude = 10;
            for (int i = 0; i < 10; i++)
            {
                var x = original.X + rnd.Next(-shakeAmplitude, shakeAmplitude);
                var y = original.Y + rnd.Next(-shakeAmplitude, shakeAmplitude);
                form.Location = new Point(x, y);
                System.Threading.Thread.Sleep(20);
            }
            form.Location = original;
        }
    }
}
