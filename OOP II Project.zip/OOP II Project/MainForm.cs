﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_II_Project
{
    public partial class MainForm : Form
    {
        private User loggedInUser;
        private bool isClosing = false;

        // Constructor
        public MainForm(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            if (loggedInUser != null)
            {
                UserProfileForm userProfileForm = new UserProfileForm(loggedInUser);
                userProfileForm.Show();
            }
            else
            {
                MessageBox.Show("First you must log in!");
            }
        }

        private void btnNotes_Click(object sender, EventArgs e)
        {
            if (loggedInUser != null)
            {
                FormNotes formNotes = new FormNotes(loggedInUser);
                formNotes.Show();
            }
            else
            {
                MessageBox.Show("First you must log in!");
            }
        }

        private void btnSalaryCalculator_Click(object sender, EventArgs e)
        {
            FormSalaryCalculator formSalaryCalculator = new FormSalaryCalculator(loggedInUser);
            formSalaryCalculator.Show();
        }

        private void btnReminder_Click(object sender, EventArgs e)
        {
            if (loggedInUser != null)
            {
                FormReminders formReminders = new FormReminders(loggedInUser);
                formReminders.Show();
            }
            else
            {
                MessageBox.Show("First you must log in!");
            }
        }

        private void btnPhoneBook_Click(object sender, EventArgs e)
        {
            // Eğer kullanıcı giriş yapmışsa, FormPhoneBook penceresini aç
            if (loggedInUser != null)
            {
                FormPhoneBook formPhoneBook = new FormPhoneBook(loggedInUser);
                formPhoneBook.Show();
            }
            else
            {
                MessageBox.Show("First you must log in!");
            }
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return; 
            isClosing = true; 

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false; 

            }
        }
}
}



