﻿namespace OOP_II_Project
{
    partial class UserProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtProfileName = new System.Windows.Forms.TextBox();
            this.txtProfileMail = new System.Windows.Forms.TextBox();
            this.txtProfileSurname = new System.Windows.Forms.TextBox();
            this.txtProfilePassword = new System.Windows.Forms.TextBox();
            this.rchtxtProfileAddress = new System.Windows.Forms.RichTextBox();
            this.msktxtProfilePhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.lblProfileSalary = new System.Windows.Forms.Label();
            this.pictureBoxProfile = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLoadPhoto = new System.Windows.Forms.Button();
            this.ExportButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProfile)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(189, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "Profile Page";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(137, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(110, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Surname:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(118, 361);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(136, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "E-Mail:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(103, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Password:";
            // 
            // txtProfileName
            // 
            this.txtProfileName.Location = new System.Drawing.Point(212, 136);
            this.txtProfileName.Name = "txtProfileName";
            this.txtProfileName.Size = new System.Drawing.Size(245, 30);
            this.txtProfileName.TabIndex = 7;
            // 
            // txtProfileMail
            // 
            this.txtProfileMail.Location = new System.Drawing.Point(212, 265);
            this.txtProfileMail.Name = "txtProfileMail";
            this.txtProfileMail.Size = new System.Drawing.Size(245, 30);
            this.txtProfileMail.TabIndex = 9;
            // 
            // txtProfileSurname
            // 
            this.txtProfileSurname.Location = new System.Drawing.Point(212, 179);
            this.txtProfileSurname.Name = "txtProfileSurname";
            this.txtProfileSurname.Size = new System.Drawing.Size(245, 30);
            this.txtProfileSurname.TabIndex = 10;
            // 
            // txtProfilePassword
            // 
            this.txtProfilePassword.Location = new System.Drawing.Point(212, 308);
            this.txtProfilePassword.Name = "txtProfilePassword";
            this.txtProfilePassword.Size = new System.Drawing.Size(245, 30);
            this.txtProfilePassword.TabIndex = 12;
            // 
            // rchtxtProfileAddress
            // 
            this.rchtxtProfileAddress.Location = new System.Drawing.Point(212, 361);
            this.rchtxtProfileAddress.Name = "rchtxtProfileAddress";
            this.rchtxtProfileAddress.Size = new System.Drawing.Size(245, 117);
            this.rchtxtProfileAddress.TabIndex = 13;
            this.rchtxtProfileAddress.Text = "";
            // 
            // msktxtProfilePhoneNumber
            // 
            this.msktxtProfilePhoneNumber.Location = new System.Drawing.Point(212, 222);
            this.msktxtProfilePhoneNumber.Mask = "(999) 000-0000";
            this.msktxtProfilePhoneNumber.Name = "msktxtProfilePhoneNumber";
            this.msktxtProfilePhoneNumber.Size = new System.Drawing.Size(245, 30);
            this.msktxtProfilePhoneNumber.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(212, 509);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(245, 62);
            this.button1.TabIndex = 15;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 25);
            this.label8.TabIndex = 16;
            this.label8.Text = "Salary:";
            // 
            // lblProfileSalary
            // 
            this.lblProfileSalary.AutoSize = true;
            this.lblProfileSalary.Location = new System.Drawing.Point(567, 136);
            this.lblProfileSalary.Name = "lblProfileSalary";
            this.lblProfileSalary.Size = new System.Drawing.Size(0, 25);
            this.lblProfileSalary.TabIndex = 17;
            // 
            // pictureBoxProfile
            // 
            this.pictureBoxProfile.Location = new System.Drawing.Point(15, 43);
            this.pictureBoxProfile.Name = "pictureBoxProfile";
            this.pictureBoxProfile.Size = new System.Drawing.Size(250, 250);
            this.pictureBoxProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxProfile.TabIndex = 18;
            this.pictureBoxProfile.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.pictureBoxProfile);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.btnLoadPhoto);
            this.panel1.Location = new System.Drawing.Point(480, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(293, 435);
            this.panel1.TabIndex = 19;
            // 
            // btnLoadPhoto
            // 
            this.btnLoadPhoto.Location = new System.Drawing.Point(15, 310);
            this.btnLoadPhoto.Name = "btnLoadPhoto";
            this.btnLoadPhoto.Size = new System.Drawing.Size(250, 62);
            this.btnLoadPhoto.TabIndex = 16;
            this.btnLoadPhoto.Text = "Load Photo";
            this.btnLoadPhoto.UseVisualStyleBackColor = true;
            this.btnLoadPhoto.Click += new System.EventHandler(this.btnLoadPhoto_Click);
            // 
            // ExportButton
            // 
            this.ExportButton.Location = new System.Drawing.Point(62, 509);
            this.ExportButton.Name = "ExportButton";
            this.ExportButton.Size = new System.Drawing.Size(109, 62);
            this.ExportButton.TabIndex = 20;
            this.ExportButton.Text = "Export";
            this.ExportButton.UseVisualStyleBackColor = true;
            this.ExportButton.Click += new System.EventHandler(this.ExportButton_Click);
            // 
            // UserProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(943, 623);
            this.Controls.Add(this.ExportButton);
            this.Controls.Add(this.lblProfileSalary);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.msktxtProfilePhoneNumber);
            this.Controls.Add(this.rchtxtProfileAddress);
            this.Controls.Add(this.txtProfilePassword);
            this.Controls.Add(this.txtProfileSurname);
            this.Controls.Add(this.txtProfileMail);
            this.Controls.Add(this.txtProfileName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UserProfileForm";
            this.Text = "UserProfileForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnFormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.UserProfileForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProfile)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtProfileName;
        private System.Windows.Forms.TextBox txtProfileMail;
        private System.Windows.Forms.TextBox txtProfileSurname;
        private System.Windows.Forms.TextBox txtProfilePassword;
        private System.Windows.Forms.RichTextBox rchtxtProfileAddress;
        private System.Windows.Forms.MaskedTextBox msktxtProfilePhoneNumber;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblProfileSalary;
        private System.Windows.Forms.PictureBox pictureBoxProfile;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLoadPhoto;
        private System.Windows.Forms.Button ExportButton;
    }
}