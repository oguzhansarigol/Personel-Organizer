﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_II_Project
{
    public partial class FormSalaryCalculator : Form
    {
        private User loggedInUser;
        private bool isClosing = false;

        public FormSalaryCalculator(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            this.Load += new System.EventHandler(this.FormSalaryCalculator_Load);
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }



        private void btnCalculate_Click(object sender, EventArgs e)
            {
                // Kullanıcıdan alınan değerler
                int experience = int.Parse(txtExperience.Text);
                string city = cboCity.SelectedItem.ToString();
                string educationLevel = cboEducation.SelectedItem.ToString();
                string foreignLanguage= cboForeign.SelectedItem.ToString();
                //bool knowsForeignLanguage = chkForeignLanguage.Checked;
                //bool isManager = chkManager.Checked;
                //bool isPartTime = chkPartTime.Checked;
                //string family=cboFamily.SelectedItem.ToString();
                string manager= cboManager.SelectedItem.ToString();
                bool isMarried = chkMarry.Checked;
                bool isSix = chk6years.Checked;
                bool isSeven = chk7years.Checked;
                bool isEighteen = chk18years.Checked;   

               // Temel ücret
               double baseSalary = 26829; // www.bmo.org.tr/en-az-ucret/ 'e göre yaptım

               // Deneyim katsayısı
               double experienceMultiplier = GetExperienceMultiplier(experience);

               // Şehir katsayısı
               double cityMultiplier = GetCityMultiplier(city);

               // Eğitim seviyesi katsayısı
               double educationMultiplier = GetEducationMultiplier(educationLevel);

               //Yabancı dil bilgisini hesaplayan katsayı yeniden
               double foreignLanguageMultiplier = GetForeignMultiplier(foreignLanguage);

               //Aile durumunu hesaplama
             //double familyMultiplier = GetFamilySituation(family); combox iptal
               //Menajerlik Durumu Hesaplama
               double managerMultiplier = GetManager(manager);
               
               double familyMultiplier = 0.0;
               if (isMarried)
               {
                   familyMultiplier += 0.20; // Evli ve eşi çalışmıyor
               }
               if (isSix)
               {
                   familyMultiplier += 0.20; // 0-6 yaş arası çocuk
               }
               if (isSeven)
               {
                   familyMultiplier += 0.30; // 7-18 yaş arası çocuk
               }
               if (isEighteen)
               {
                   familyMultiplier += 0.40; // 18 yaş üstü (Üniversite lisans / ön lisans öğrencisi olmak koşuluyla)
               }

            // Yabancı dil bilgisi katsayısı
            //double foreignLanguageMultiplier = knowsForeignLanguage ? 1.1 : 1.0;

            // Yöneticilik katsayısı 1.2
            // double managerMultiplier = isManager ? 1.2 : 1.0;

            // Maaş hesaplama
            double salary = (experienceMultiplier + cityMultiplier + educationMultiplier + foreignLanguageMultiplier+ familyMultiplier + managerMultiplier + 1 ) * baseSalary  ;

            // part-time ise %50 indirim
            //if (isPartTime)
            //{
            //    salary *= 0.5;
            //}
            if (loggedInUser.UserType == UserType.PartTimeUser)
            {
                salary *= 0.5; // Part-time ise %50 indirim
            }

            // Show salary
            lblCalculatedSalary.Text = "Calculated Salary: " + salary.ToString("C2");
                
                loggedInUser.Salary = salary;

        }
        private double GetForeignMultiplier(string foreignLanguage) {
            switch (foreignLanguage)
            {
                case "Documented knowledge of English": return 0.20; // Belgelendirilmiş İngilizce bilgisi
                case "Graduation from a School Teaching in English": return 0.20; // İngilizce eğitim veren okul mezuniyeti
                case "Documented knowledge of other foreign languages (for each language)": return 0.05; // Belgelendirilmiş diğer yabancı dil bilgisi (her dil için)

                default: return 0.0; // Diğer durumlar 
            }
        }
        private double GetManager(string manager) {
            switch (manager)
            {
                case "Team Leader/Group Manager/Technical Manager/Software Architect": return 0.50; // Takım Lideri/Grup Yöneticisi/Teknik Yönetici/Yazılım Mimarı
                case "Project Manager": return 0.75; // Proje Yöneticisi 
                case "Director/Projects Manager": return 0.85; // Direktör/Projeler Yöneticisi
                case "CTO/General Manager": return 1.00; // CTO/Genel Müdür
                case "Information Technology Officer/Manager (maximum 5 IT personnel)": return 0.40; // Bilgi İşlem Sorumlusu/Müdürü en fazla 5 personel 
                case "Information Technology Officer/Manager(more than 5 IT personnel)": return 0.60; // Bilgi İşlem Sorumlusu/Müdürü 5 den fazla

                default: return 0.0; // Diğer durumlar 
            }
        }
        private double GetExperienceMultiplier(int experience)
        {
            // Yeni katsayılar
            if (experience >= 2 && experience <= 4) return 0.60;
            if (experience >= 5 && experience <= 9) return 1.00;
            if (experience >= 10 && experience <= 14) return 1.20;
            if (experience >= 15 && experience <= 20) return 1.35;
            if (experience > 20) return 1.50;

            // Eğer deneyim 2 yılın altındaysa
            return 0.0;
        }
        private double GetCityMultiplier(string city)
        {
            // Yaşanılan İle Göre Ücret Katsayıları BMO'ya göre hesapladım
            switch (city)
            {
                case "Istanbul": return 0.30;
                case "Ankara": return 0.20;
                case "Izmir": return 0.20;
                case "Kocaeli":
                case "Sakarya":
                case "Düzce":
                case "Bolu":
                case "Yalova": return 0.10;
                case "Edirne":
                case "Kırklareli":
                case "Tekirdağ": return 0.10;
                case "Trabzon":
                case "Ordu":
                case "Giresun":
                case "Rize":
                case "Artvin":
                case "Gümüşhane": return 0.05;
                case "Bursa":
                case "Eskişehir":
                case "Bilecik": return 0.05;
                case "Aydın":
                case "Denizli":
                case "Muğla": return 0.05;
                case "Adana":
                case "Mersin": return 0.05;
                case "Balıkesir":
                case "Çanakkale": return 0.05;
                case "Antalya":
                case "Isparta":
                case "Burdur": return 0.05;
                default: return 0.0; // Diğer iller // Other cities
            }
        }


        private double GetEducationMultiplier(string educationLevel)
        {
            // Tablo-3: Alınan Akademik Dereceye Göre Ücret Katsayıları
            switch (educationLevel)
            {
                case "Related Master": return 0.10; // Meslek alanı ile ilgili yüksek lisans
                case "Related PhD": return 0.30; // Meslek alanı ile ilgili doktora
                case "Related Associate Prof": return 0.35; // Meslek alanı ile ilgili doçentlik
                case "Unrelated Master": return 0.05; // Meslek alanı ile ilgili olmayan yüksek lisans
                case "Unrelated PhD Or Associate Prof": return 0.15; // Meslek alanı ile ilgili olmayan doktora/doçentlik
                default: return 0.0; // Diğer durumlar (Bachelor veya belirtilmemiş dereceler)
            }
        }
       
        //private double GetFamilySituation(string family)
        //{
        //    //Tablo-6: Aile Durumuna Göre Ücret Katsayıları
        //    switch (family)
        //    {
        //        case "He is married and his wife does not work": return 0.20; // Evli ve eşi çalışmıyor
        //        case "0-6 years old child": return 0.20; // 0-6 yaş arası çocuk
        //        case "Children aged 7-18": return 0.30; // 7-18 yaş arası çocuk
        //        case "Children over the age of 18": return 0.40; // 18 yaş üstü  (Üniversite lisans / ön lisans öğrencisi olmak koşuluyla) 
               
        //        default: return 0.0; // Diğer durumlar 
        //    }
        //}


            private Label lblExperience;
            private TextBox txtExperience;
            private Label lblCity;
            private ComboBox cboCity;
            private Label lblEducation;
            private ComboBox cboEducation;
            private Button btnCalculate;
            private Label lblCalculatedSalary;

        private void lblEducation_Click(object sender, EventArgs e)
        {

        }

        private void FormSalaryCalculator_Load(object sender, EventArgs e)
        {
            if (loggedInUser != null)
            {
                lblUsername.Text = $"Welcome, {loggedInUser.Username}";
            }
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return; 
            isClosing = true; 

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false;
            }
        
        }
    }
    }

