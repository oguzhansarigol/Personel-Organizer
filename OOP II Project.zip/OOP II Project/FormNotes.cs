﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace OOP_II_Project
{
    public partial class FormNotes : Form
    {
        private User loggedInUser;
        private List<string> notes;
        private bool isClosing = false;

        public FormNotes(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            notes = LoadNotes();
            UpdateNoteList();
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }

        private List<string> LoadNotes()
        {
            List<string> loadedNotes = new List<string>();
            try
            {
                string[] lines = File.ReadAllLines("notes.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 2)
                    {
                        string username = parts[0];
                        string noteContent = string.Join(",", parts.Skip(1));
                        if (username == loggedInUser.Username)
                        {
                            loadedNotes.Add(noteContent);
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                loadedNotes = new List<string>();
            }
            return loadedNotes;
        }

        private void SaveNotes()
        {
            var allNotes = new List<string>();
            try
            {
                string[] lines = File.ReadAllLines("notes.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 2)
                    {
                        string username = parts[0];
                        if (username != loggedInUser.Username)
                        {
                            allNotes.Add(line);
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                // Dosya yoksa yeni dosya oluşturulacak
            }

            foreach (string note in notes)
            {
                allNotes.Add($"{loggedInUser.Username},{note}");
            }

            File.WriteAllLines("notes.csv", allNotes);
        }

        public void ExportCsvToExcel(string csvFilePath, string excelFilePath)
        {
            var lines = File.ReadAllLines(csvFilePath);
            var data = lines.Select(line => line.Split(',')).ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Notes");
                for (int i = 0; i < data.Count; i++)
                {
                    for (int j = 0; j < data[i].Length; j++)
                    {
                        worksheet.Cell(i + 1, j + 1).Value = data[i][j];
                    }
                }
                workbook.SaveAs(excelFilePath);
            }
        }
        private void UpdateNoteList()
        {
            listBox1.Items.Clear();
            listBox1.Items.AddRange(notes.ToArray());
        }

        private void btnAddNote_Click(object sender, EventArgs e)
        {
            string newNote = richTextBox1.Text.Trim();
            if (!string.IsNullOrEmpty(newNote))
            {
                notes.Add(newNote);
                UpdateNoteList();
                                SaveNotes();
                richTextBox1.Clear();
            }
        }

        private void btnUpdateNote_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                notes[listBox1.SelectedIndex] = richTextBox1.Text.Trim();
                UpdateNoteList();
                SaveNotes();
            }
        }

        private void btnDeleteNote_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                notes.RemoveAt(listBox1.SelectedIndex);
                UpdateNoteList();
                SaveNotes();
                richTextBox1.Clear();
            }
        }

        private void btnListNote_Click(object sender, EventArgs e)
        {
            UpdateNoteList();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                richTextBox1.Text = notes[listBox1.SelectedIndex];
            }
        }

        private void FormNotes_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return;
            isClosing = true; 

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false;
            }
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            string csvFilePath = "notes.csv";
            string downloadsFolder = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
            string excelFilePath = Path.Combine(downloadsFolder, "notes.xlsx");


            ExportCsvToExcel(csvFilePath, excelFilePath);

            // Kullanıcıya Excel dosyasını indirmesi için bir mesaj göster
            MessageBox.Show("Kullanıcı verileri başarıyla Excel formatında dışa aktarıldı.", "Export Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
