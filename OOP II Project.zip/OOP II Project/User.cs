﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_II_Project
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Email { get; set; }
        public UserType UserType { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public double Salary { get; set; }
        public string PhotoPath { get; set; }

        // Memento metotları
        public UserMemento CreateMemento()
        {
            return new UserMemento(Username, Password, Ad, Soyad, Email, UserType, PhoneNumber, Address, Salary, PhotoPath);
        }

        public void Restore(UserMemento memento)
        {
            Username = memento.Username;
            Password = memento.Password;
            Ad = memento.Ad;
            Soyad = memento.Soyad;
            Email = memento.Email;
            UserType = memento.UserType;
            PhoneNumber = memento.PhoneNumber;
            Address = memento.Address;
            Salary = memento.Salary;
            PhotoPath = memento.PhotoPath;
        }
    }

    public class UserMemento
    {
        public string Username { get; }
        public string Password { get; }
        public string Ad { get; }
        public string Soyad { get; }
        public string Email { get; }
        public UserType UserType { get; }
        public string PhoneNumber { get; }
        public string Address { get; }
        public double Salary { get; }
        public string PhotoPath { get; }

        public UserMemento(string username, string password, string ad, string soyad, string email, UserType userType, string phoneNumber, string address, double salary, string photopath)
        {
            Username = username;
            Password = password;
            Ad = ad;
            Soyad = soyad;
            Email = email;
            UserType = userType;
            PhoneNumber = phoneNumber;
            Address = address;
            Salary = salary;
            PhotoPath = photopath;
        }
    }
}
