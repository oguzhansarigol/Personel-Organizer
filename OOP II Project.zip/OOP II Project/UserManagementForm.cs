﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail; // E-posta gönderimi için eklenen kütüphane
using System.Windows.Forms;

namespace OOP_II_Project
{
    public partial class UserManagementForm : Form
    {
        private User loggedInUser;
        private List<User> users;
        private bool isClosing = false;
        public UserManagementForm(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            users = LoadUsers();
            PopulateUserList();
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }

        private List<User> LoadUsers()
        {
            List<User> loadedUsers = new List<User>();
            try
            {
                string[] lines = File.ReadAllLines("users.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 6)
                    {
                        User user = new User
                        {
                            Username = parts[0],
                            Password = parts[1],
                            Ad = parts[2],
                            Soyad = parts[3],
                            Email = parts[4]
                        };

                        UserType userType;
                        if (Enum.TryParse(parts[5], out userType))
                        {
                            user.UserType = userType;
                        }
                        else
                        {
                            continue;
                        }

                        loadedUsers.Add(user);
                    }
                }
            }
            catch (FileNotFoundException)
            {
                loadedUsers = new List<User>();
            }
            return loadedUsers;
        }

        private void PopulateUserList()
        {
            listBoxUsers.Items.Clear();
            foreach (var user in users)
            {
                listBoxUsers.Items.Add($"{user.Username} ({user.UserType})");
            }
        }

        private void btnChangeUserType_Click(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedIndex != -1)
            {
                string selectedUser = listBoxUsers.SelectedItem.ToString().Split(' ')[0];
                User user = users.Find(u => u.Username == selectedUser);
                if (user != null)
                {
                    UserType newType;
                    if (Enum.TryParse(comboBoxUserTypes.SelectedItem.ToString(), out newType))
                    {
                        user.UserType = newType;
                        SaveUsers();
                        PopulateUserList();
                        MessageBox.Show("The user type has been changed successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Invalid user type selected.");
                    }
                }
            }
        }

        private void SaveUsers()
        {
            List<string> lines = new List<string>();
            foreach (var user in users)
            {
                lines.Add($"{user.Username},{user.Password},{user.Ad},{user.Soyad},{user.Email},{user.UserType}");
            }
            File.WriteAllLines("users.csv", lines);
        }

        private void btnShowMain_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UserManagementForm_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return; 
            isClosing = true; 

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false; 
            }
        }

        // Yeni şifre sıfırlama ve e-posta gönderme metodu
        private async void SendNewPasswordEmail(string userEmail, string newPassword)
        {
            try
            {
                progressBar1.Value = 0; // İlerleme çubuğunu sıfırla

                // SMTP ayarlarını yapma
                SmtpClient client = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("oguzhanproje1@gmail.com", "projeoop2024"),
                    EnableSsl = true,
                };

                // E-posta oluşturma
                MailMessage mailMessage = new MailMessage
                {
                    From = new MailAddress("oguzhanproje1@gmail.com"),
                    Subject = "Your New Password",
                    Body = $"Your new password is: {newPassword}",
                    IsBodyHtml = true,
                };
                mailMessage.To.Add(userEmail);

                // E-posta gönderme
                progressBar1.PerformStep(); // İlerleme çubuğunu güncelle
                await client.SendMailAsync(mailMessage);
                progressBar1.PerformStep(); // İlerleme çubuğunu güncelle

                MessageBox.Show("The new password has been sent to the user's email address.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while sending the email: {ex.Message}");
            }
            finally
            {
                progressBar1.Value = 0; // İlerleme çubuğunu sıfırla
            }
        }

        private void btnResetPassword_Click(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedIndex != -1)
            {
                string selectedUser = listBoxUsers.SelectedItem.ToString().Split(' ')[0];
                User user = users.Find(u => u.Username == selectedUser);
                if (user != null)
                {
                    string newPassword = txtNewPassword.Text; // txtNewPassword alanındaki şifreyi al
                    if (string.IsNullOrEmpty(newPassword))
                    {
                        MessageBox.Show("Please enter a new password.");
                        return;
                    }

                    user.Password = newPassword;
                    SaveUsers();
                    SendNewPasswordEmail(user.Email, newPassword);
                }
                else
                {
                    MessageBox.Show("User not found.");
                }
            }
        }
    }
}
