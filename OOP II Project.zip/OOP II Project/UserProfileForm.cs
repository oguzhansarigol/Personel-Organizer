﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using ClosedXML.Excel;


namespace OOP_II_Project
{
    public partial class UserProfileForm : Form
    {
        private User loggedInUser;
        private List<User> users;
        private bool isClosing = false;

        // Memento ve Caretaker nesneleri için değişkenler
        private Stack<UserMemento> undoStack = new Stack<UserMemento>();
        private Stack<UserMemento> redoStack = new Stack<UserMemento>();

        public UserProfileForm(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            users = LoadUsers();
            LoadUserProfile();

            
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler(UserProfileForm_KeyDown);
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }

        private void UserProfileForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Z)
            {
                Undo();
            }
            else if (e.Control && e.KeyCode == Keys.Y)
            {
                Redo();
            }
        }

        private void LoadUserProfile()
        {
            txtProfileName.Text = loggedInUser.Ad;
            txtProfileSurname.Text = loggedInUser.Soyad;
            txtProfileMail.Text = loggedInUser.Email;
            msktxtProfilePhoneNumber.Text = loggedInUser.PhoneNumber;
            rchtxtProfileAddress.Text = loggedInUser.Address;
            txtProfilePassword.Text = loggedInUser.Password;
            lblProfileSalary.Text = "Calculated Salary: " + loggedInUser.Salary.ToString("C2");
            if (!string.IsNullOrEmpty(loggedInUser.PhotoPath) && File.Exists(loggedInUser.PhotoPath))
            {
                pictureBoxProfile.Image = Image.FromFile(loggedInUser.PhotoPath);
            }
            // İlk durumu memento olarak kaydet
            undoStack.Push(loggedInUser.CreateMemento());
        }

        private List<User> LoadUsers()
        {
            List<User> loadedUsers = new List<User>();
            try
            {
                string[] lines = File.ReadAllLines("users.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 9)
                    {
                        User user = new User
                        {
                            Username = parts[0],
                            Password = parts[1],
                            Ad = parts[2],
                            Soyad = parts[3],
                            Email = parts[4],
                            PhoneNumber = parts[6],
                            Address = parts[7],
                            PhotoPath = parts[8]  // PhotoPath ekleniyor
                        };

                        UserType userType;
                        if (Enum.TryParse(parts[5], out userType))
                        {
                            user.UserType = userType;
                        }
                        else
                        {
                            Console.WriteLine($"Incorrect user type: {parts[5]}");
                            continue;
                        }

                        loadedUsers.Add(user);
                    }
                    else
                    {
                        Console.WriteLine($"Faulty line: {line}");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                loadedUsers = new List<User>();
            }
            return loadedUsers;
        }

        private void UpdateUserInCsv(User updatedUser)
        {
            var lines = File.ReadAllLines("users.csv").ToList();
            for (int i = 0; i < lines.Count; i++)
            {
                var parts = lines[i].Split(',');
                if (parts[0] == updatedUser.Username)
                {
                    lines[i] = $"{updatedUser.Username},{updatedUser.Password},{updatedUser.Ad},{updatedUser.Soyad},{updatedUser.Email},{updatedUser.UserType},{updatedUser.PhoneNumber},{updatedUser.Address},{updatedUser.PhotoPath}";  
                    break;
                }
            }
            File.WriteAllLines("users.csv", lines);
        }
        public void ExportCsvToExcel(string csvFilePath, string excelFilePath)
        {
            var lines = File.ReadAllLines(csvFilePath);
            var data = lines.Select(line => line.Split(',')).ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Users");
                for (int i = 0; i < data.Count; i++)
                {
                    for (int j = 0; j < data[i].Length; j++)
                    {
                        worksheet.Cell(i + 1, j + 1).Value = data[i][j];
                    }
                }
                workbook.SaveAs(excelFilePath);
            }
        }
        private void ExportButton_Click(object sender, EventArgs e)
        {
            string csvFilePath = "users.csv";
            

            // İndirilenler klasörüne yolu al
            string downloadsFolder = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
            string excelFilePath = Path.Combine(downloadsFolder, "users.xlsx");


            ExportCsvToExcel(csvFilePath, excelFilePath);

            // Kullanıcıya Excel dosyasını indirmesi için bir mesaj göster
            MessageBox.Show("Kullanıcı verileri başarıyla Excel formatında dışa aktarıldı.", "Export Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
           
            undoStack.Push(loggedInUser.CreateMemento());
            redoStack.Clear(); 

            if (!string.IsNullOrEmpty(txtProfilePassword.Text) && !txtProfilePassword.Text.Equals(loggedInUser.Password))
            {
                loggedInUser.Password = txtProfilePassword.Text;
            }

            loggedInUser.Ad = txtProfileName.Text;
            loggedInUser.Soyad = txtProfileSurname.Text;
            loggedInUser.Email = txtProfileMail.Text;
            loggedInUser.PhoneNumber = msktxtProfilePhoneNumber.Text;
            loggedInUser.Address = rchtxtProfileAddress.Text;

            UpdateUserInCsv(loggedInUser);

            MessageBox.Show("The profile has been updated successfully.");
        }

        

        public void Undo()
        {
            if (undoStack.Count > 0)
            {
                redoStack.Push(loggedInUser.CreateMemento());
                loggedInUser.Restore(undoStack.Pop());
                LoadUserProfile();
            }
        }

        public void Redo()
        {
            if (redoStack.Count > 0)
            {
                undoStack.Push(loggedInUser.CreateMemento());
                loggedInUser.Restore(redoStack.Pop());
                LoadUserProfile();
            }
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return; 
            isClosing = true; 

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false; 
            }
        }

        private void btnLoadPhoto_Click(object sender, EventArgs e)
        {
            
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                openFileDialog.Title = "Select a Photo";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        
                        string selectedFilePath = openFileDialog.FileName;

                        
                        string photosDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UserPhotos");

                        
                        if (!Directory.Exists(photosDirectory))
                        {
                            Directory.CreateDirectory(photosDirectory);
                        }

                        
                        string fileName = Path.GetFileName(selectedFilePath);
                        string destinationFilePath = Path.Combine(photosDirectory, fileName);

                        
                        File.Copy(selectedFilePath, destinationFilePath, true);

                        
                        loggedInUser.PhotoPath = destinationFilePath;
                        UpdateUserInCsv(loggedInUser);

                        
                        pictureBoxProfile.Image = Image.FromFile(destinationFilePath);

                        MessageBox.Show("Photo loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while loading the photo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

      
    }
}

