﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using OOP_II_Project;

namespace OOP_II_Project
{
    public enum UserType
    {
        Admin,
        User,
        PartTimeUser
    }

    //public class User
    //{
    //    public string Username { get; set; }
    //    public string Password { get; set; }
    //    public string Ad { get; set; }
    //    public string Soyad { get; set; }
    //    public string Email { get; set; }
    //    public UserType UserType { get; set; }
    //    // Diğer kullanıcı özelliklerini buraya ekleyebilirsiniz
    //}

    public partial class LoginForm : Form
    {
        private List<User> users;
        private User loggedInUser;
        private bool isClosing = false;

        public LoginForm()
        {
            InitializeComponent();
            users = LoadUsers();
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);

        }

        private List<User> LoadUsers()
        {
            List<User> loadedUsers = new List<User>();
            try
            {
                string[] lines = File.ReadAllLines("users.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 6) // Her satırın en az 6 parçadan oluştuğundan emin ol
                    {
                        User user = new User
                        {
                            Username = parts[0],
                            Password = parts[1],
                            Ad = parts[2],
                            Soyad = parts[3],
                            Email = parts[4]
                        };

                        // UserType alanını enum'a dönüştürmeden önce uygun bir değeri olduğundan emin ol
                        UserType userType;
                        if (Enum.TryParse(parts[5], out userType))
                        {
                            user.UserType = userType;
                        }
                        else
                        {
                            Console.WriteLine($"Incorrect user type: {parts[5]}");
                            continue; // Hatalı satırları atla
                        }

                        loadedUsers.Add(user);
                    }
                    else
                    {
                        Console.WriteLine($"Faulty line: {line}");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                // Dosya bulunamadıysa veya henüz oluşturulmadıysa yeni bir liste oluştur
                loadedUsers = new List<User>();
            }
            return loadedUsers;
        }

        private bool Kaydet(User newUser)
        {
            try
            {
                users.Add(newUser);
                string newUserLine = $"{newUser.Username},{newUser.Password},{newUser.Ad},{newUser.Soyad},{newUser.Email},{newUser.UserType}";
                File.AppendAllText("users.csv", newUserLine + Environment.NewLine);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while registering the user: " + ex.Message);
                return false;
            }
        }

        private void btnPasswordShow_Click(object sender, EventArgs e)
        {
            txtSifre.UseSystemPasswordChar = !txtSifre.UseSystemPasswordChar;
        }

        private void btnUyeOl_Click(object sender, EventArgs e)
        {
            string username = txtUserLog.Text;
            string password = txtLogPassword.Text;
            string ad = txtLogAd.Text;
            string soyad = txtLogSoyad.Text;
            string email = txtLogMail.Text;
            
            //mail kontrol regEx ile
            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Enter a valid email address.");
                return;
            }

            // Kullanıcı bilgileriyle yeni bir User nesnesi oluşturma
            User newUser = new User
            {
                Username = username,
                Password = password,
                Ad = ad,
                Soyad = soyad,
                Email = email,
                UserType = UserType.User // Varsayılan olarak normal bir kullanıcı
            };

            // yeni kullanıcı kaydetme metodu
            bool kaydedildi = Kaydet(newUser);

            if (kaydedildi)
            {
                MessageBox.Show("The user has been successfully registered.");
            }
            else
            {
                MessageBox.Show("An error occurred while registering the user.");
            }
        }

        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = txtSifre.Text;

            loggedInUser = AuthenticateUser(username, password);

            if (loggedInUser != null)
            {
                if (loggedInUser.UserType == UserType.Admin)
                {
                    // Admin girişi başarılı, yönetim penceresini açabiliriz
                    MainForm userPanel = new MainForm(loggedInUser);
                    UserManagementForm adminPanel = new UserManagementForm(loggedInUser);
                    userPanel.Show();
                    adminPanel.Show();
                    this.Hide();
                }
                else
                {
                    // Diğer kullanıcılar 
                     MainForm userPanel = new MainForm(loggedInUser);
                     userPanel.Show();
                     this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Invalid username or password!");
            }
        }

        private User AuthenticateUser(string username, string password)
        {
            return users.Find(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && u.Password == password);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtLogPassword.UseSystemPasswordChar = !txtLogPassword.UseSystemPasswordChar;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return; 
            isClosing = true; 

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false; 
            }
        }
    }
}
