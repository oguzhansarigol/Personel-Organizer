﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace OOP_II_Project
{
    public partial class FormPhoneBook : Form
    {
        private User loggedInUser;
        private List<Contact> contacts;
        private bool isClosing = false;

        public FormPhoneBook(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            contacts = LoadContacts();
            InitializeDataGridView();
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }

        private void InitializeDataGridView()
        {
            dataGridViewContacts.DataSource = contacts;
            dataGridViewContacts.AutoGenerateColumns = true;
        }
        public void ExportCsvToExcel(string csvFilePath, string excelFilePath)
        {
            var lines = File.ReadAllLines(csvFilePath);
            var data = lines.Select(line => line.Split(',')).ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("PhoneBook");
                for (int i = 0; i < data.Count; i++)
                {
                    for (int j = 0; j < data[i].Length; j++)
                    {
                        worksheet.Cell(i + 1, j + 1).Value = data[i][j];
                    }
                }
                workbook.SaveAs(excelFilePath);
            }
        }
        private List<Contact> LoadContacts()
        {
            List<Contact> loadedContacts = new List<Contact>();
            try
            {
                string[] lines = File.ReadAllLines("phonebook.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 7)  // Updated to 7 to include Username
                    {
                        string username = parts[0];
                        if (username == loggedInUser.Username)  // Only load contacts for the logged-in user
                        {
                            Contact contact = new Contact
                            {
                                Username = username,  // Assign username to contact
                                FirstName = parts[1],
                                LastName = parts[2],
                                PhoneNumber = parts[3],
                                Address = parts[4],
                                Description = parts[5],
                                Email = parts[6]
                            };
                            loadedContacts.Add(contact);
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                loadedContacts = new List<Contact>();
            }
            return loadedContacts;
        }

        private bool SaveContact(Contact newContact)
        {
            try
            {
                newContact.Username = loggedInUser.Username;
                contacts.Add(newContact);
                string newContactLine = $"{newContact.Username},{newContact.FirstName},{newContact.LastName},{newContact.PhoneNumber},{newContact.Address},{newContact.Description},{newContact.Email}";
                File.AppendAllText("phonebook.csv", newContactLine + Environment.NewLine);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving the contact: " + ex.Message);
                return false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                Contact newContact = new Contact
                {
                    FirstName = txtFirstName.Text,
                    LastName = txtLastName.Text,
                    PhoneNumber = txtPhoneNumber.Text,
                    Address = txtAddress.Text,
                    Description = txtDescription.Text,
                    Email = txtEmail.Text
                };

                if (SaveContact(newContact))
                {
                    MessageBox.Show("The contact has been successfully registered.");
                    dataGridViewContacts.DataSource = null;
                    dataGridViewContacts.DataSource = contacts;
                }
            }
            else
            {
                MessageBox.Show("Please fill in all fields correctly.");
            }
        }

        private bool ValidateFields()
        {
            // Email doğrulama
            if (!Regex.IsMatch(txtEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Enter a valid email address.");
                return false;
            }

            // Telefon numarası doğrulama (555) 555 55 55 formatında
            //if (!Regex.IsMatch(txtPhoneNumber.Text, @"^\(\d{3}\) \d{3} \d{2} \d{2}$"))
            //{
            //    MessageBox.Show("Geçerli bir telefon numarası girin: (555) 555 55 55");
            //    return false;
            //}

            return true;
        }

        // Diğer butonlar için metodlar (Update, Delete, List) buraya eklenebilir.

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridViewContacts.SelectedRows.Count > 0)
            {
                // Seçili satırı al
                int selectedIndex = dataGridViewContacts.SelectedRows[0].Index;
                Contact selectedContact = contacts[selectedIndex];

                // Yeni bilgileri al ve kontağı güncelle
                selectedContact.FirstName = txtFirstName.Text;
                selectedContact.LastName = txtLastName.Text;
                selectedContact.PhoneNumber = txtPhoneNumber.Text;
                selectedContact.Address = txtAddress.Text;
                selectedContact.Description = txtDescription.Text;
                selectedContact.Email = txtEmail.Text;

                // CSV dosyasını güncelle
                SaveAllContacts();

                // DataGridView'i güncelle
                dataGridViewContacts.DataSource = null;
                dataGridViewContacts.DataSource = contacts;

                MessageBox.Show("Contact updated successfully.");
            }
            else
            {
                MessageBox.Show("Please select a contact to update.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewContacts.SelectedRows.Count > 0)
            {
                // Seçili satırı al
                int selectedIndex = dataGridViewContacts.SelectedRows[0].Index;
                Contact selectedContact = contacts[selectedIndex];

                // Kontağı listeden sil
                contacts.Remove(selectedContact);

                // CSV dosyasını güncelle
                SaveAllContacts();

                // DataGridView'i güncelle
                dataGridViewContacts.DataSource = null;
                dataGridViewContacts.DataSource = contacts;

                MessageBox.Show("Contact deleted successfully.");
            }
            else
            {
                MessageBox.Show("Please select a contact to delete.");
            }
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            dataGridViewContacts.DataSource = null;
            dataGridViewContacts.DataSource = contacts;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return;
            isClosing = true;

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false;

            }
        
        }
        private void SaveAllContacts()
        {
            try
            {
                List<string> lines = new List<string>();
                foreach (Contact contact in contacts)
                {
                    string line = $"{contact.Username},{contact.FirstName},{contact.LastName},{contact.PhoneNumber},{contact.Address},{contact.Description},{contact.Email}";
                    lines.Add(line);
                }
                File.WriteAllLines("phonebook.csv", lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving contacts: " + ex.Message);
            }
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            {
                string csvFilePath = "PhoneBook.csv";

                // İndirilenler klasörüne yolu al
                string downloadsFolder = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
                string excelFilePath = Path.Combine(downloadsFolder, "PhoneBook.xlsx");

                ExportCsvToExcel(csvFilePath, excelFilePath);

                // Kullanıcıya Excel dosyasını indirmesi için bir mesaj göster
                MessageBox.Show($"Kullanıcı verileri başarıyla Excel formatında dışa aktarıldı: {excelFilePath}", "Export Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }

    public class Contact
    {
        public string Username { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
        public string Email { get; set; }
    }
}
