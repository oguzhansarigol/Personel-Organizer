﻿namespace OOP_II_Project
{
    partial class FormSalaryCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExperience = new System.Windows.Forms.Label();
            this.txtExperience = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.cboCity = new System.Windows.Forms.ComboBox();
            this.lblEducation = new System.Windows.Forms.Label();
            this.cboEducation = new System.Windows.Forms.ComboBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblCalculatedSalary = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cboForeign = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboManager = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkMarry = new System.Windows.Forms.CheckBox();
            this.chk18years = new System.Windows.Forms.CheckBox();
            this.chk6years = new System.Windows.Forms.CheckBox();
            this.chk7years = new System.Windows.Forms.CheckBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblExperience
            // 
            this.lblExperience.AutoSize = true;
            this.lblExperience.Location = new System.Drawing.Point(49, 104);
            this.lblExperience.Name = "lblExperience";
            this.lblExperience.Size = new System.Drawing.Size(158, 24);
            this.lblExperience.TabIndex = 0;
            this.lblExperience.Text = "Experience Year:";
            // 
            // txtExperience
            // 
            this.txtExperience.Location = new System.Drawing.Point(211, 96);
            this.txtExperience.Name = "txtExperience";
            this.txtExperience.Size = new System.Drawing.Size(238, 32);
            this.txtExperience.TabIndex = 1;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(156, 166);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(49, 24);
            this.lblCity.TabIndex = 2;
            this.lblCity.Text = "City:";
            // 
            // cboCity
            // 
            this.cboCity.FormattingEnabled = true;
            this.cboCity.Items.AddRange(new object[] {
            "Ankara",
            "Istanbul",
            "Izmir",
            "Kocaeli",
            "Sakarya",
            "Düzce",
            "Bolu",
            "Yalova ",
            "Edirne",
            "Kırklareli",
            "Tekirdağ",
            "Trabzon",
            "Ordu",
            "Giresun",
            "Rize",
            "Artvin",
            "Gümüşhane",
            "Bursa",
            "Eskişehir",
            "Bilecik",
            "Aydın",
            "Denizli",
            "Muğla",
            "Adana",
            "Mersin ",
            "Balıkesir",
            "Çanakkale",
            "Antalya",
            "Isparta",
            "Burdur",
            "Other Cities"});
            this.cboCity.Location = new System.Drawing.Point(211, 158);
            this.cboCity.Name = "cboCity";
            this.cboCity.Size = new System.Drawing.Size(238, 32);
            this.cboCity.TabIndex = 3;
            // 
            // lblEducation
            // 
            this.lblEducation.AutoSize = true;
            this.lblEducation.Location = new System.Drawing.Point(49, 228);
            this.lblEducation.Name = "lblEducation";
            this.lblEducation.Size = new System.Drawing.Size(156, 24);
            this.lblEducation.TabIndex = 4;
            this.lblEducation.Text = "Education Level:";
            this.lblEducation.Click += new System.EventHandler(this.lblEducation_Click);
            // 
            // cboEducation
            // 
            this.cboEducation.FormattingEnabled = true;
            this.cboEducation.Items.AddRange(new object[] {
            "Related Master",
            "Related PhD",
            "Related Associate Prof",
            "Unrelated Master",
            "Unrelated PhD Or Associate Prof",
            "None"});
            this.cboEducation.Location = new System.Drawing.Point(211, 220);
            this.cboEducation.Name = "cboEducation";
            this.cboEducation.Size = new System.Drawing.Size(238, 32);
            this.cboEducation.TabIndex = 5;
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.White;
            this.btnCalculate.Location = new System.Drawing.Point(225, 32);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(205, 53);
            this.btnCalculate.TabIndex = 9;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblCalculatedSalary
            // 
            this.lblCalculatedSalary.AutoSize = true;
            this.lblCalculatedSalary.BackColor = System.Drawing.Color.LightSeaGreen;
            this.lblCalculatedSalary.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCalculatedSalary.Location = new System.Drawing.Point(454, 48);
            this.lblCalculatedSalary.Name = "lblCalculatedSalary";
            this.lblCalculatedSalary.Size = new System.Drawing.Size(254, 37);
            this.lblCalculatedSalary.TabIndex = 10;
            this.lblCalculatedSalary.Text = "Calculated Salary:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(478, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Foreign Language:";
            // 
            // cboForeign
            // 
            this.cboForeign.FormattingEnabled = true;
            this.cboForeign.Items.AddRange(new object[] {
            "Documented knowledge of English",
            "Graduation from a School Teaching in English",
            "Documented knowledge of other foreign languages (for each language)",
            "None"});
            this.cboForeign.Location = new System.Drawing.Point(659, 93);
            this.cboForeign.Name = "cboForeign";
            this.cboForeign.Size = new System.Drawing.Size(388, 32);
            this.cboForeign.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(500, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 24);
            this.label2.TabIndex = 13;
            this.label2.Text = "Managerial Job:";
            // 
            // cboManager
            // 
            this.cboManager.FormattingEnabled = true;
            this.cboManager.Items.AddRange(new object[] {
            "Team Leader/Group Manager/Technical Manager/Software Architect",
            "Project Manager",
            "Director/Projects Manager",
            "CTO/General Manager",
            "Information Technology Officer/Manager (maximum 5 IT personnel)",
            "Information Technology Officer/Manager(more than 5 IT personnel)",
            "None"});
            this.cboManager.Location = new System.Drawing.Point(659, 156);
            this.cboManager.Name = "cboManager";
            this.cboManager.Size = new System.Drawing.Size(388, 32);
            this.cboManager.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 24);
            this.label3.TabIndex = 15;
            this.label3.Text = "Family Situation:";
            // 
            // chkMarry
            // 
            this.chkMarry.AutoSize = true;
            this.chkMarry.Location = new System.Drawing.Point(221, 277);
            this.chkMarry.Name = "chkMarry";
            this.chkMarry.Size = new System.Drawing.Size(394, 28);
            this.chkMarry.TabIndex = 17;
            this.chkMarry.Text = "He is married and his wife does not work";
            this.chkMarry.UseVisualStyleBackColor = true;
            // 
            // chk18years
            // 
            this.chk18years.AutoSize = true;
            this.chk18years.Location = new System.Drawing.Point(221, 380);
            this.chk18years.Name = "chk18years";
            this.chk18years.Size = new System.Drawing.Size(272, 28);
            this.chk18years.TabIndex = 18;
            this.chk18years.Text = "Children over the age of 18";
            this.chk18years.UseVisualStyleBackColor = true;
            // 
            // chk6years
            // 
            this.chk6years.AutoSize = true;
            this.chk6years.Location = new System.Drawing.Point(221, 311);
            this.chk6years.Name = "chk6years";
            this.chk6years.Size = new System.Drawing.Size(192, 28);
            this.chk6years.TabIndex = 19;
            this.chk6years.Text = "0-6 years old child";
            this.chk6years.UseVisualStyleBackColor = true;
            // 
            // chk7years
            // 
            this.chk7years.AutoSize = true;
            this.chk7years.Location = new System.Drawing.Point(221, 345);
            this.chk7years.Name = "chk7years";
            this.chk7years.Size = new System.Drawing.Size(199, 28);
            this.chk7years.TabIndex = 20;
            this.chk7years.Text = "Children aged 7-18";
            this.chk7years.UseVisualStyleBackColor = true;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Roboto", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblUsername.Location = new System.Drawing.Point(47, 38);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(91, 34);
            this.lblUsername.TabIndex = 22;
            this.lblUsername.Text = "label5";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.Controls.Add(this.lblCalculatedSalary);
            this.panel1.Controls.Add(this.btnCalculate);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 433);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1091, 153);
            this.panel1.TabIndex = 23;
            // 
            // FormSalaryCalculator
            // 
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(1091, 586);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.chk7years);
            this.Controls.Add(this.chk6years);
            this.Controls.Add(this.chk18years);
            this.Controls.Add(this.chkMarry);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboManager);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboForeign);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboEducation);
            this.Controls.Add(this.lblEducation);
            this.Controls.Add(this.cboCity);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.txtExperience);
            this.Controls.Add(this.lblExperience);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Name = "FormSalaryCalculator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnFormClosing);
            this.Load += new System.EventHandler(this.FormSalaryCalculator_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboForeign;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboManager;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkMarry;
        private System.Windows.Forms.CheckBox chk18years;
        private System.Windows.Forms.CheckBox chk6years;
        private System.Windows.Forms.CheckBox chk7years;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Panel panel1;
    }
}