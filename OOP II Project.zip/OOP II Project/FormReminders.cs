﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;


namespace OOP_II_Project
{
    public partial class FormReminders : Form
    {
        private User loggedInUser;
        private List<Reminder> reminders;
        private bool isClosing = false;

        public FormReminders(User user)
        {
            InitializeComponent();
            loggedInUser = user;
            reminders = LoadReminders();
            UpdateReminderList();
            //this.FormClosing += new FormClosingEventHandler(OnFormClosing);
        }

        private List<Reminder> LoadReminders()
        {
            List<Reminder> loadedReminders = new List<Reminder>();
            try
            {
                string[] lines = File.ReadAllLines("reminders.csv");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 5)
                    {
                        string username = parts[0];
                        if (username == loggedInUser.Username)
                        {
                            DateTime date = DateTime.Parse(parts[1]);
                            string type = parts[2];
                            string summary = parts[3];
                            string description = parts[4];

                            Reminder reminder;
                            if (type == "Meeting")
                            {
                                reminder = new MeetingReminder(date, summary, description);
                            }
                            else
                            {
                                reminder = new TaskReminder(date, summary, description);
                            }
                            loadedReminders.Add(reminder);
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                loadedReminders = new List<Reminder>();
            }
            return loadedReminders;
        }
        public void ExportCsvToExcel(string csvFilePath, string excelFilePath)
        {
            var lines = File.ReadAllLines(csvFilePath);
            var data = lines.Select(line => line.Split(',')).ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Reminder");
                for (int i = 0; i < data.Count; i++)
                {
                    for (int j = 0; j < data[i].Length; j++)
                    {
                        worksheet.Cell(i + 1, j + 1).Value = data[i][j];
                    }
                }
                workbook.SaveAs(excelFilePath);
            }
        }
        private void SaveReminders()
        {
            var allReminders = new List<string>();
            foreach (var reminder in reminders)
            {
                string type = reminder is MeetingReminder ? "Meeting" : "Task";
                allReminders.Add($"{loggedInUser.Username},{reminder.Date},{type},{reminder.Summary},{reminder.Description}");
            }
            File.WriteAllLines("reminders.csv", allReminders);
        }

        private void UpdateReminderList()
        {
            listBox1.Items.Clear();
            foreach (var reminder in reminders)
            {
                listBox1.Items.Add($"{reminder.Date} - {reminder.Summary}");
            }
        }

        private void btnAddReminder_Click(object sender, EventArgs e)
        {
            DateTime date = dateTimePicker1.Value;
            string summary = txtSummary.Text;
            string description = txtDescription.Text;
            string type = cmbReminderType.SelectedItem.ToString();

            Reminder reminder;
            if (type == "Meeting")
            {
                reminder = new MeetingReminder(date, summary, description);
            }
            else
            {
                reminder = new TaskReminder(date, summary, description);
            }

            reminders.Add(reminder);
            UpdateReminderList();
            SaveReminders();
        }

        private void btnUpdateReminder_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                var selectedReminder = reminders[listBox1.SelectedIndex];
                selectedReminder.Date = dateTimePicker1.Value;
                selectedReminder.Summary = txtSummary.Text;
                selectedReminder.Description = txtDescription.Text;
                UpdateReminderList();
                SaveReminders();
            }
        }

        private void btnDeleteReminder_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                reminders.RemoveAt(listBox1.SelectedIndex);
                UpdateReminderList();
                SaveReminders();
            }
        }

        private void btnListReminder_Click(object sender, EventArgs e)
        {
            UpdateReminderList();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                var selectedReminder = reminders[listBox1.SelectedIndex];
                dateTimePicker1.Value = selectedReminder.Date;
                txtSummary.Text = selectedReminder.Summary;
                txtDescription.Text = selectedReminder.Description;
                cmbReminderType.SelectedItem = selectedReminder is MeetingReminder ? "Meeting" : "Task";
            }
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (isClosing) return;
            isClosing = true;

            DialogResult result = MessageBox.Show("Really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
                isClosing = false; 
            }
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            string csvFilePath = "Reminders.csv";

            // İndirilenler klasörüne yolu al
            string downloadsFolder = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
            string excelFilePath = Path.Combine(downloadsFolder, "reminders.xlsx");

            ExportCsvToExcel(csvFilePath, excelFilePath);

            // Kullanıcıya Excel dosyasını indirmesi için bir mesaj göster
            MessageBox.Show($"Kullanıcı verileri başarıyla Excel formatında dışa aktarıldı: {excelFilePath}", "Export Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
